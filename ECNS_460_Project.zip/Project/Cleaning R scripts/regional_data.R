# Load  libraries
library(dplyr)
library(tidyr)
library(readr)
library(readxl)
library(janitor)
library(stringr)

# Load Data
data = read_csv("Project/renewable_energy_data.csv")
head(data)

data = data|>
  select(-country)|>
  select(-id_number)|>
  select(-re_capacity_percent)|>
  select(-re_percent_change)

regional_data <- data |>
  filter(region %in% c("africa", "americas", "asia", "europe", "oceania")) |>
  group_by(region, year) |>
  summarize(
    total_capacity = sum(total_capacity, na.rm = TRUE),
    total_re_capacity = sum(total_re_capacity, na.rm = TRUE),
    total_nre_capacity = sum(total_nre_capacity, na.rm = TRUE),
    .groups = "drop"
  )
(regional_data)

# Create percentage change in renewable energy column
percentage_data = regional_data |>
  mutate(re_capacity_percent = total_re_capacity/total_capacity * 100)|>
  mutate(re_percent_change = re_capacity_percent - lag(re_capacity_percent))
head(percentage_data)

# Delete 2014 because needed 2013 for lagged data, so does not have RE change
percentage_data = percentage_data |>
  filter(year != 2014)
head(percentage_data)

# Write the cleaned data to a new CSV
write_csv(percentage_data, "Project/regional_energy_data.csv")
