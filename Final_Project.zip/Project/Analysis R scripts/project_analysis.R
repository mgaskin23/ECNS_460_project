rm(list = ls())

# Load necesary libraries
library(readxl)
library(dplyr)
library(ggplot2)
library(spdep)
library(plm)
library(tidyr)
library(Hmisc)

#"C:/Users/sofia/OneDrive/Desktop/Advanced Data Analytics/Project/Clean Data"

# PREVIEW DATA -----------------------------------------------------------------
# Load and view data
data = read.csv("merged_data.csv")
head(data)
glimpse(data)
summary(data)


# CORRELATION ANALYSIS --------------------------------------------------------
# Select columns to compare
percent_change_data = data [, c("gdp_growth", "re_change")]

summary(percent_change_data)

# Pairwise correlation
cor_matrix = cor(percent_change_data, use = "pairwise.complete.obs", method = "pearson")
print(cor_matrix)

# Correlation significance
cor_results = rcorr(as.matrix(percent_change_data)) 
print(cor_results)

# Correlation coefficients and p-values
cor_coefficients = cor_results$r
p_values = cor_results$P
cor_coefficients
p_values

# CAUSAL ANALYSIS --------------------------------------------------------------

# Linear regression model
# Estimate model using ordinary least squares
pooled_ols <- lm(gdp_growth ~ re_change, data = data)
summary(pooled_ols)


# LOOOK ATH THIS IN A SECOND
pooled_ols <- lm(gdp_growth ~ re_change * country, data = data)
summary(pooled_ols)


# Convert to panel data
panel_data = pdata.frame(data, index =c("country", "year"))
summary(panel_data)

# Fixed Effects Model
fe_model <- plm(gdp_growth ~ re_change, data = panel_data, model = "within")
summary(fe_model)

fe_reg <- feols(gdp_growth~re_capacity_percent+ factor(year)|country,data) 

# assuming homoscedasticity & uncorrelated errors to use as baseline comparison
summary(fe_reg,vcov="iid")

# assuming heteroscedasticity and uncorrelated errors for comparison
# May underestimate error dependence if there is clustering
summary(fe_reg,vcov="hetero")

# clustering errors by country
# assumes independence between countries but accounts for  temporal correlation 
# in the error within each country
summary(fe_reg,cluster="country")

# clustering errors by region
summary(fe_reg,cluster="region")

# clustering errors by region-by-year
summary(fe_reg,cluster="region^year")

# clustering errors by year
summary(fe_reg,cluster="year")


