
# Load necesary libraries
library(readxl)
library(dplyr)
library(ggplot2)
library(spdep)
library(splm)
library(tidyr)
library(shiny)

#set working directory 
#"C:/Users/megan/OneDrive/Desktop/Classes FALL 2024/ECNS 460/Project/merged_data.csv"

# Load and view data
data = read.csv("merged_data.csv")
head(data)

#USER INTERFACE
ui <- fluidPage(
  titlePanel("Yearly Averages of Renewable Energy and GDP Growth"),
  sidebarLayout(
    sidebarPanel(
      selectInput("region", "Select Region:", choices = unique(data$region)),
      sliderInput("years", "Select Year Range:", min = 2015, max = 2023, value = c(2015, 2023)),
      selectizeInput(
        "variables", 
        "Select Variables to Graph:", 
        choices = list(
          "GDP Growth" = "gdp_growth",
          "Renewable Capacity" = "total_re_capacity",
          "Percent Renewable" = "re_capacity_percent",
          "Percent Change Renewable" = "re_change",
          "Total Capacity" = "total_capacity",
          "Total Nonrenewable Capacity" = "total_nre_capacity"
        ), 
        selected = c("gdp_growth"),  # Default selection
        multiple = TRUE  # Enable multiple selection
      )
    ),
    mainPanel(
      plotOutput("trendPlot"),
      tableOutput("summaryTable")
    )
  )
)

#SERVER-SIDE LOGIC 
server <- function(input, output) {
  # Filter the data by region and year
  filtered_data <- reactive({
    data %>%
      filter(region == input$region & year >= input$years[1] & year <= input$years[2])
  })
  
  # Compute yearly averages for all numeric variables
  summarized_data <- reactive({
    filtered_data() %>%
      group_by(year) %>%
      summarize(across(where(is.numeric), ~mean(.x, na.rm = TRUE)))  # Using ~ for the lambda function
  })
  
  # Prepare data for plotting (long format for ggplot)
  plot_data <- reactive({
    req(input$variables)  # Ensure variables are selected
    summarized_data() %>%
      select(year, all_of(input$variables)) %>%
      pivot_longer(cols = all_of(input$variables), names_to = "Variable", values_to = "Value")
  })
  
  # Mapping of data column names to user-friendly names
  variable_names <- c(
    "gdp_growth" = "GDP Growth",
    "total_re_capacity" = "Renewable Capacity",
    "re_capacity_percent" = "Percent Renewable",
    "re_change" = "Percent Change Renewable",
    "total_capacity" = "Total Capacity",
    "total_nre_capacity" = "Total Nonrenewable Capacity"
  )
  
  # Plot the selected variables
  output$trendPlot <- renderPlot({
    req(plot_data())  # Ensure plot data is available
    
    # Update legend labels with user-friendly names
    ggplot(plot_data(), aes(x = year, y = Value, color = Variable)) +
      geom_line(size = 1) +
      geom_point(size = 2) +
      labs(
        title = paste("Yearly Averages of Selected Variables in", input$region),
        x = "Year",
        y = "Value"
      ) +
      scale_color_manual(
        values = c("blue", "red", "green", "purple", "orange", "pink"),  # Custom colors
        labels = variable_names[input$variables]  # Use the mapping for the legend labels
      ) +
      theme_minimal()
  })
  
  # Display a summary table of the selected variables
  output$summaryTable <- renderTable({
    req(plot_data())  # Ensure plot data is available
    
    plot_data() %>%
      pivot_wider(names_from = "Variable", values_from = "Value") %>%
      rename_with(~ gsub("_", " ", .), everything())  # Make column names more readable
  })
}

#CREATE SHINY APP
shinyApp(ui = ui, server = server)


