
#load necessary packages
library(dplyr)
library(tidyr)
library(stringr)
library(janitor)
library(ggplot2)
library(readr)
#load in the GDP data 

#####VISUALIZING THE DATA#############  

  
#plot of total renewable energy capacity by region over time
ggplot(region_data, aes(x = year, y = total_renewable_capacity, color = region, group = region)) +
    geom_line(size = 1.2) +
    geom_point(size = 1.5) +  
    labs(
      title = "Total Renewable Energy Capacity by Region Over Time",
      x = "Year",
      y = "Total Renewable Energy Capacity",
      color = "Region"
    ) +
    scale_y_continuous(labels = scales::label_number(scale = 1e-3, suffix = "K"))+
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5),
      axis.text.x = element_text(angle = 45, hjust = 1)
    )


#plot of average percent change in renewable energy capacity and GDP by region
ggplot(region_data, aes(x = year)) +
  geom_line(aes(y = avg_percent_change_renewable, color = region), size = 1.2) +
  geom_line(aes(y = avg_percent_change_gdp, color = region), linetype = "dashed", size = 1) +
  labs(
    title = "Average Percent Change in Renewable Capacity and GDP by Region",
    x = "Year",
    y = "Average Percent Change in Renewable Capacity",
    color = "Region"
  ) +
  scale_y_continuous(
    name = "Average Percent Change in Renewable Capacity",
    sec.axis = sec_axis(~ ., name = "Average Percent Change in GDP")
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1))

#plot of Average Percent Change in GDP BY region over time  
ggplot(region_data, aes(x = year, y = avg_percent_change_gdp, color = region, group = region)) +
  geom_line(size = 1.2) +
  geom_point(size = 1.5) +  
  labs(
    title = "Average Percent change in GDP by Region Over Time",
    x = "Year",
    y = "Average Percent change in GDP",
    color = "Region"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

#plot of the average renewable energy capacity by region over time
ggplot(region_data, aes(x = year, y = avg_renewable_capacity, color = region, group = region)) +
  geom_line(size = 1.2) +
  geom_point(size = 1.5) +  
  labs(
    title = "Average Renewable energy capacity by region over time",
    x = "Year",
    y = "Average renewable energy capacity",
    color = "Region"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

#plot of the average percent change in renewable energy capacity by region over time
ggplot(region_data, aes(x = year, y = avg_percent_change_renewable, color = region, group = region)) +
  geom_line(size = 1.2) +
  geom_point(size = 1.5) +  
  labs(
    title = "Average percent change in Renewable energy capacity by region over time",
    x = "Year",
    y = "Percent change in renewable energy capacity",
    color = "Region"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )


#plot of each region's percent change in renewable energy capacity and GDP on separate plots
ggplot(region_data, aes(x = year)) +
  geom_line(aes(y = avg_percent_change_renewable, color = "Percent change in Renewable Capacity", linetype = "Percent change in Renewable Capacity"), size = 1.2) +
  geom_line(aes(y = avg_percent_change_gdp, color = "GDP Change", linetype = "GDP Change"), size = 1) +
  labs(
    title = "Average Percent Change in Renewable Capacity and GDP by Region",
    x = "Year",
    y = "Average Percent Change in Renewable Capacity",
    color = "Variable",
    linetype = "Variable"
  ) +
  scale_y_continuous(
    name = "Average Percent Change in Renewable Capacity",
    sec.axis = sec_axis(~ ., name = "Average Percent Change in GDP")
  ) +
  scale_color_manual(values = c("Percent change in Renewable Capacity" = "blue", "GDP Change" = "red")) +
  scale_linetype_manual(values = c("Percent change in Renewable Capacity" = "solid", "GDP Change" = "dashed")) +
  facet_wrap(~ region) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )
