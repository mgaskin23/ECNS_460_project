rm(list =ls())

# Load  libraries
library(dplyr)
library(tidyr)
library(readr)
library(readxl)
library(janitor)
library(stringr)

# Load Data
gdp_data = read.csv("API_NY.GDP.MKTP.KD.ZG_DS2_en_csv_v2_31631.csv")

# View Data
head(gdp_data)

#convert the GDP data to long format  
gdp_long = gdp_data|>
  pivot_longer(
    cols = starts_with("x"),
    names_to = "year",
    values_to = "gdp_growth"
  )|>
  na.omit()

head(gdp_long)

# Clean the data
# Change names 
clean_data = gdp_long |>
  clean_names()|>
  # Remove the x before YYYY
  rename_with(~ str_remove(., "^x"))

head(clean_data)

# Function for string cleaning 
clean_string <- function(x) {
  x |>
    str_to_lower() |>                      
    str_replace_all("[[:punct:]]", "") |>  
    str_replace_all("\\b(the|a|and|of|in|for)\\b", "") |>  
    str_trim() |>                          
    str_squish()                      
}

# String cleaning
clean_data = clean_data |>
  mutate(across(where(is.character), clean_string))|>
  mutate(year = str_remove(year, "^x"))|>
  distinct()

head(clean_data)


# Filter years 2014-2023 and select relevant columns
clean_gdp_data = clean_data |>
  filter(year >= 2014 & year <= 2023 ) |>
  rename(country = country_name)|>
  select(-country_code)|>
  select(-indicator_name)|>
  select(-indicator_code)
  
head(clean_gdp_data)


# Write the cleaned data to a new CSV
write_csv(clean_gdp_data, "clean_gdp_data.csv")
