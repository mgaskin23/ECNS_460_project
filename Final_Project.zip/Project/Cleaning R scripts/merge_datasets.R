rm(list = ls())

# Merge the datasets together

# Load the datasets
re_data = read.csv("renewable_energy_data.csv")
head(re_data)

gdp_data = read.csv("clean_gdp_data.csv")
head(gdp_data)

# Merge the data
merged_data = re_data |>
  full_join(gdp_data, by = c("country", "year"))

# # Create a unique ID by combining 'country' and 'year'
# merged_data = merged_data|>
#   mutate(country_year = paste(country, year, sep = "_")) |>
# Move the 'country_year' column to the first position
#   select(country_year, everything())  

duplicate_rows <- merged_data[duplicated(merged_data), ]
duplicate_rows

# Drop cases where gdp_growth had data for a country that re_change did not
# and drop where re_energy had data for a country that gdp did not
merged_data = merged_data|>
  filter(!is.na(gdp_growth) & !is.na(re_change))

clean_merged_data = merged_data|>
  mutate(id = row_number()) |>
  select(id, everything())

head(clean_merged_data)


# Write the merged data to a new CSV
write_csv(clean_merged_data, "merged_data.csv")

